package cl.santotomas.creditcard;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MainActivity extends AppCompatActivity {

    EditText edtnombre, edtapellido, edttarjeta, edtmes, edtanio, edtcodigo, edtcalle, edtciudad;
    Button btnregistrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtnombre=(EditText)findViewById(R.id.edtnombre);
        edtapellido=(EditText)findViewById(R.id.edtapellido);
        edttarjeta=(EditText)findViewById(R.id.edttarjeta);
        edtmes=(EditText)findViewById(R.id.edtmes);
        edtanio=(EditText)findViewById(R.id.edtanio);
        edtcodigo=(EditText)findViewById(R.id.edtcodigo);
        edtcalle=(EditText)findViewById(R.id.edtcalle);
        edtciudad=(EditText)findViewById(R.id.edtciudad);
        btnregistrar=(Button)findViewById(R.id.btnagregar);

        btnregistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                agregartarjeta();
            }
        });
    }
    public Connection ConexionBD(){
        Connection conexion=null;
        try {
            StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll() .build();
            StrictMode.setThreadPolicy(policy);
            Class.forName("net.sourceforge.jtds.jdbc.Driver").newInstance();
            conexion= DriverManager.getConnection("jdbc:jtds:sqlserver://26.49.37.94;databaseName=tarjeta;user=admin;passowrd=root;");
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
        }
        return conexion;
    }
    public void agregartarjeta(){
        try {
            PreparedStatement pst=ConexionBD().prepareStatement("insert into tarjeta value(?,?,?,?,?,?,?,?)");
            pst.setString(1,edtnombre.getText().toString());
            pst.setString(2,edtapellido.getText().toString());
            pst.setString(3,edttarjeta.getText().toString());
            pst.setString(4,edtmes.getText().toString());
            pst.setString(5,edtanio.getText().toString());
            pst.setString(6,edtcodigo.getText().toString());
            pst.setString(7,edtcalle.getText().toString());
            pst.setString(3,edtciudad.getText().toString());
            pst.executeUpdate();
            Toast.makeText(getApplicationContext(),"REGISTRO AGREGADO CORRECTAMENTE",Toast.LENGTH_SHORT).show();
        }catch (SQLException e){
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }
}